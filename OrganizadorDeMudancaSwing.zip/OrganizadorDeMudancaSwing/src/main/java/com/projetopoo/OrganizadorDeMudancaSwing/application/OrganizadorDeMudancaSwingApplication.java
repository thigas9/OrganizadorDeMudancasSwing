package com.projetopoo.OrganizadorDeMudancaSwing.application;

import com.projetopoo.OrganizadorDeMudancaSwing.view.TelaPrincipal;

public class OrganizadorDeMudancaSwingApplication {
    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }
}
